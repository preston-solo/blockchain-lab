# QA TESTER REPORT - Tata

## 6 Discrepancies Found:

1. **Missing Day 2 contracts** - Created VulnerableBank, SecureBank, SecureStorage, LabToken
2. **Node.js version** - Lab manual said v20, needed v22
3. **Solidity version** - 0.8.19 incompatible with OpenZeppelin v5, updated to 0.8.28
4. **Missing hardhat-toolbox** - Added @nomicfoundation/hardhat-toolbox@hh2
5. **ESM/CommonJS conflict** - Resolved configuration issues
6. **Ganache port error** - Corrected command syntax

All issues documented and resolved.
