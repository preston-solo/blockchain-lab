# Blockchain Lab Submission
**Student:** Tata
**Role:** QA Tester (Day 1) → Network Engineer (Day 2)

## Key Findings
Found 6 discrepancies in lab manual. See reports/QA-REPORT.md
