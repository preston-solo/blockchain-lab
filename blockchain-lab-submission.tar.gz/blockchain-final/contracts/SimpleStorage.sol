// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract SimpleStorage {
    uint256 public storedValue;
    
    function setValue(uint256 _val) public {
        storedValue = _val;
    }
    
    function getValue() public view returns (uint256) {
        return storedValue;
    }
}
